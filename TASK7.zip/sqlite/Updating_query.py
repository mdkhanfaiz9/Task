import sqlite3
conn = sqlite3.connect("student_data.db")
cur = conn.cursor()

conn.execute("UPDATE STUDENT SET STUDENT_NAME = 'CARRY', STUDENT_EMAIL = CARRY@GMAIL.COM WHERE STUDENT_ROLL_NO = 2")
conn.commit()