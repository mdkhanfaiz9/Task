import sqlite3
conn = sqlite3.connect("student_data.db")
cur = conn.cursor()

conn.execute("DELETE FROM STUDENT WHERE STUDENT_ROLL_NO = 3")
conn.commit()