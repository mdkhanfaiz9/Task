import sqlite3
conn = sqlite3.connect("student_data.db")
cur = conn.cursor()

data = conn.execute("""SELECT STUDENT.STUDENT_NAME,
STUDENT.STUDENT_ROLL_NO,
FEES.STUDENT_FEE
FROM STUDENT JOIN FEES  WHERE
STUDENT.STUDENT_ROL_NO = FEES.STUDENT_ROLL_NO""")
for i in data:
    print(i)


conn.close()