import sqlite3
conn = sqlite3.connect("student_data.db")
cur = conn.cursor()

get_data = conn.execute("SELECT * FROM STUDENT ")
for i in get_data:
    print_(i)
print_()
print_()

fetch_data = conn.execiute("SELECT * FROM STUDENT WHERE STUDENT_CLASS = '6th' and STUDENT_NAME = 'CARRY' ")
for i in fetch_data:
    print_(i)
conn.close()