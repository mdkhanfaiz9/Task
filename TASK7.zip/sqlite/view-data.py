import sqlite3
conn = sqlite3.connect("student_data.db")
cur = conn.cursor()

get_data = conn.execute("SELECT * FROM STUDENT order by STUDENT_ROLL_NO DESC ")
for i in get_data:
    print (i)

conn.close()
