import sqlite3

from winerror import TPMAPI_E_TPM_COMMAND_ERROR

conn = sqlite3.connect("student_data.db")
cur = conn.cursor()
l = []
while True:
    var1 = input('enter name here: ')
    var2 = input('enter grade here: ')
    var3 = input('enter email here: ')
    var4 = int(input('enter phone number here: '))
    t = (var1, var2, var3, var4)
    l.append(t)

    student_1 = """INSERT INTO STUDENT
    (STUDENT_NAME, STUDENT_CLASS, STUDENT_EMAIL, STUDENT_PH_NO)
    VALUES(?,?,?,?)"""
    repeat = input("do you want to add more data? (yes/no): ")
    if repeat == "no" or repeat == "NO":
        break

cur.executemany(student_1,l)
conn.commit()